# SignLanguageDetection > 2024-12-30 8:12pm
https://universe.roboflow.com/signlanguageannotation/signlanguagedetection-ynvoz

Provided by a Roboflow user
License: CC BY 4.0

